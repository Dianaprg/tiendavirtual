package com.mintic.TiendaVirtualG7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaVirtualG7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
